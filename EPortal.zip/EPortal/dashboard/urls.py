from django.urls import path

from . import views

app_name = "dashboard"
urlpatterns = [
    path("", views.home, name="home"),
    path("wfh", views.wfh_request, name="wfh"),
    path("about", views.home, name="about"),
]
