import threading
from django.shortcuts import render, redirect
from django.urls import reverse
from django.core.mail import EmailMessage
from django.contrib import messages
from django.template.loader import render_to_string
from django.conf import settings
from django.http import HttpResponseRedirect
from django.utils.encoding import (
    force_bytes,
    force_str,
    DjangoUnicodeDecodeError,
)


class EmailThread(threading.Thread):
    def __init__(self, email):
        self.email = email
        threading.Thread.__init__(self)

    def run(self):
        self.email.send()


def send_wfh_email(request, user):
    hr_email = "sumitmahar78@gmail.com"
    email_subject = "Work From Home Request"
    email_body = render_to_string(
        "dashboard/wfh.html",
        {
            "user": user,
        },
    )

    email = EmailMessage(
        subject=email_subject,
        body=email_body,
        from_email=settings.EMAIL_HOST_USER,
        to=[hr_email],
    )

    EmailThread(email).start()


def home(request):
    return render(request, "dashboard/home.html", {})


def wfh_request(request):
    user = request.user
    send_wfh_email(request, user)

    messages.add_message(
        request, messages.INFO, "Your request for WFH has been sent to HR."
    )

    return HttpResponseRedirect(reverse("dashboard:home"))


def leave_request(request):
    pass
