from django.urls import path
from .views import register, login_view, activate_user, update_profile


app_name = "accounts"
urlpatterns = [
    path("login/", login_view, name="login"),
    path("signup/", register, name="signup"),
    path("update-profile/", update_profile, name="update_profile"),
    path("activate-user/<uidb64>/<token>", activate_user, name="activate"),
]
