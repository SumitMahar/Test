from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .forms import CustomUserChangeForm, CustomUserCreationForm
from .models import CustomUser, UserProfile


class ProfileInline(admin.TabularInline):
    model = UserProfile


class CustomUserAdmin(UserAdmin):
    form = CustomUserChangeForm
    add_form = CustomUserCreationForm
    model = CustomUser
    list_display = [
        "username",
        "first_name",
        "last_name",
        "date_of_joining",
        "email",
        "is_email_verified",
        "is_staff",
    ]
    fieldsets = UserAdmin.fieldsets + (
        ("Custom Fields", {"fields": ("date_of_joining", "is_email_verified")}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        (
            "Custom Fields",
            {
                "fields": (
                    "first_name",
                    "last_name",
                    "email",
                    "is_email_verified",
                    "date_of_joining",
                )
            },
        ),
    )

    ordering = ("-date_of_joining",)
    inlines = [ProfileInline]


admin.site.register(CustomUser, CustomUserAdmin)
admin.site.register(UserProfile)
