import threading
from django.shortcuts import redirect, render
from django.urls import reverse_lazy
from django.views.generic import CreateView
from django.urls import reverse
from django.http import HttpResponseRedirect, Http404
from django.contrib.auth import login, logout, authenticate
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.core.mail import EmailMessage
from django.contrib import messages
from django.conf import settings
from django.utils.encoding import (
    force_bytes,
    force_str,
    DjangoUnicodeDecodeError,
)

from .utils import generate_token
from .models import CustomUser
from .forms import CustomUserCreationForm, LoginForm, UserUpdateForm, ProfileUpdateForm


class EmailThread(threading.Thread):
    def __init__(self, email):
        self.email = email
        threading.Thread.__init__(self)

    def run(self):
        self.email.send()


def send_activation_email(request, user):
    current_site = get_current_site(request)
    email_subject = "Activate your account."
    email_body = render_to_string(
        "accounts/activate.html",
        {
            "user": user,
            "domain": current_site,
            "uid": urlsafe_base64_encode(force_bytes(user.pk)),
            "token": generate_token.make_token(user),
        },
    )

    email = EmailMessage(
        subject=email_subject,
        body=email_body,
        from_email=settings.EMAIL_HOST_USER,
        to=[user.email],
    )

    EmailThread(email).start()


def register(request):
    """
    Registers and logs the new user in
    """
    if request.method == "POST":
        # Process filled form
        form = CustomUserCreationForm(data=request.POST)
        if form.is_valid():
            email = form.cleaned_data.get("email").lower()
            username = form.cleaned_data.get("username").lower()

            if CustomUser.objects.filter(username=username).first():
                messages.warning(request, "Username is taken.")

                return render(request, "accounts/signup.html", {"form": form})

            # raise Http404("Username is taken")

            if not email.endswith(".com"):
                messages.warning(
                    request,
                    "Invalid email. (Provide Official email eg: example@eblsec.com",
                )

                return render(request, "accounts/signup.html", {"form": form})

            new_user = form.save()
            send_activation_email(request, new_user)

            # messages.success(request, "We sent you an email to verify your account.")
            # return HttpResponseRedirect(reverse("accounts:login"))
            return render(
                request,
                "accounts/login.html",
                {"form": LoginForm(), "include_verify_account_section": True},
            )

    else:
        # Display blank registration form
        form = CustomUserCreationForm()

    context = {"form": form}
    return render(request, "accounts/signup.html", context)


def login_view(request):

    if request.method == "POST":
        form = LoginForm(data=request.POST)
        user = None
        if form.is_valid:
            username = request.POST.get("username").lower()
            password = request.POST.get("password")
            user = authenticate(request, username=username, password=password)

        if user and not user.is_email_verified:
            messages.add_message(
                request,
                messages.ERROR,
                "Email is not verified, please check your email inbox.",
            )
            return render(
                request,
                "accounts/login.html",
                {"form": form, "include_verify_account_section": True},
                status=401,
            )

        if not user:
            messages.add_message(
                request, messages.ERROR, "Invalid credentials, try again"
            )
            return render(request, "accounts/login.html", {"form": form}, status=401)

        login(request, user)

        return HttpResponseRedirect(reverse("dashboard:home"))

    form = LoginForm()
    return render(request, "accounts/login.html", {"form": form})


def logout_view(request):
    """Logs out the current user"""
    logout(request)
    messages.success(request, "Successfully logged out")
    return HttpResponseRedirect(reverse("dashboard:home"))


def activate_user(request, uidb64, token):

    try:
        uid = force_str(urlsafe_base64_decode(uidb64))

        user = CustomUser.objects.get(pk=uid)

    except Exception as e:
        user = None

    if user and generate_token.check_token(user, token):
        user.is_email_verified = True
        user.save()

        return render(
            request,
            "accounts/login.html",
            {"form": LoginForm(), "include_account_verified_section": True},
        )

    return render(request, "accounts/activate_failed.html", {"user": user})


def update_profile(request):
    if request.method == "POST":
        user_form = UserUpdateForm(request.POST, instance=request.user)
        profile_form = ProfileUpdateForm(
            request.POST, request.FILES, instance=request.user.userprofile
        )
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            return redirect("dashboard:home")

    else:
        user_form = UserUpdateForm(instance=request.user)
        profile_form = ProfileUpdateForm(instance=request.user.userprofile)

    context = {"user_form": user_form, "profile_form": profile_form}

    return render(request, "accounts/profile_update.html", context)
