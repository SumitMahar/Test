from dataclasses import field
from pyexpat import model
from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm

from .models import CustomUser, UserProfile


class CustomUserCreationForm(UserCreationForm):
    date_of_joining = forms.DateField(
        widget=forms.widgets.DateInput(attrs={"type": "date"})
    )
    email = forms.EmailField(
        widget=forms.EmailInput(
            attrs={"placeholder": "Your official email eg: name@eblsec.com"}
        )
    )

    class Meta:
        model = CustomUser
        fields = ("username", "first_name", "last_name", "date_of_joining", "email")


class CustomUserChangeForm(UserChangeForm):
    class Meta:
        model = CustomUser
        fields = ("username", "first_name", "last_name", "date_of_joining", "email")


class LoginForm(forms.Form):
    username = forms.CharField(
        max_length=100,
        # widget=forms.TextInput(attrs={"placeholder": "Your employee id eg: EBLSEC75"}),
    )
    password = forms.CharField(widget=forms.PasswordInput())


class UserUpdateForm(forms.ModelForm):
    first_name = forms.CharField()
    last_name = forms.CharField()

    class Meta:
        model = CustomUser
        fields = ["first_name", "last_name"]


class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ["image"]
