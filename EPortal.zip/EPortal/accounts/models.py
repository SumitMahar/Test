from cProfile import label
from email.policy import default
from logging import PlaceHolder
from operator import truediv
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone


class CustomUser(AbstractUser):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    date_of_joining = models.DateField(null=True)
    email = models.EmailField(unique=True)
    is_email_verified = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        self.username = self.username.lower()
        super().save(*args, **kwargs)

    def __str__(self):
        return self.username


class UserProfile(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    image = models.ImageField(default="default_user.png", upload_to="profile_pics")

    def __str__(self):
        return self.user.username
